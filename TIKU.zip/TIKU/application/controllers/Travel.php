<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Travel extends CI_Controller {

    public function index()
    {
        $data= $this->Travelku->Get('travel');
        $data = array('data' => $data);
        
        $this->load->view('home/index', $data, FALSE);
        
    }

    public function pesan()
    {
        ///menerima id dari home
        $id_travel= $_POST['id_travel'];

        //mengambil data travel berdasarkan id
        $data['travel']= $this->Travelku->Get_where('travel', array('id_travel' => $id_travel));

        //ambil nama travel
        $nama_travel= $data['travel'][0]['nama_travel'];

        //set session data nama dan id travel
        $this->session->set_userdata('nama_travel', $nama_travel);
        $this->session->set_userdata('id_travel', $id_travel);

        //ambil semu data jadwal
        $data['jadwal']= $this->Travelku->Get('jadwal');

        //menyimpan semua data kedalam variabel data
        $data= array('data' => $data);
        $this->load->view('pesan/index', $data, FALSE);
        
    }

    public function pesan_kursi()
    {
        ///ambil data dari id tanggal pesan
        $tanggal_pesan = $_POST['tanggal_pesan'];

        ///ambil data dari id jadwal di pesan
        $id_jadwal = $_POST['jadwal'];

        ///set session data tanggal pesan dan jadwal
        $this->session->set_userdata('tanggal_pesan', $tanggal_pesan);
        $this->session->set_userdata('id_jadwal', $id_jadwal);

        ///ambil data jadwal berdasarkan id
        $data['jadwal']=$this->Travelku->Get_where('jadwal', array('id_jadwal' => $id_jadwal));

        ///amblil data jadwal
        $jadwal= $data['jadwal'][0]['jadwal'];
        $this->session->set_userdata('jadwal', $jadwal);


        ///menampilkan data kursi
        $data['kursi']= $this->Travelku->Get('kursi');


        ///memasukan id travel menggunakan session
        $id_travel= $this->session->userdata('id_travel');

        $query_kursi_booked= $this->db->query('SELECT nokur FROM pesanan 
        WHERE id_travel="'.$id_travel.'" and id_jadwal="'.$id_jadwal.'" 
        and tanggal_pesan="'.$tanggal_pesan.'" ');

        //memasukan ke var array kursi booked

        $data['kursi_booked']= $query_kursi_booked->result_array();

        $data= array('data' => $data);
        $this->load->view('pesan_kursi/index', $data, FALSE);
        


    }

    public function identitas()
    {
        if (!empty($_POST['pilihKursi'])) 
        {
            $kursi= $_POST['pilihKursi'];
            $this->session->set_userdata('kursi',  $kursi);
            $data['kursi'] = $kursi;


            $data= array('data' => $data);
            $this->load->view('identitas/index', $data, FALSE);
        }
         else 
        {
            $this->session->sess_destroy();
            
            $data= $this->Travelku->Get('travel');
            $data= array('data' => $data);
            $this->load->view('home/index', $data, FALSE);
            
        }
        
    }

    public function identitas1()
    {
        if (!empty($_POST['pilihKursi'])) 
        {
            $kursi= $_POST['pilihKursi'];
            $this->session->set_userdata('kursi',  $kursi);
            $data['kursi'] = $kursi;


            $data= array('data' => $data);
            $this->load->view('identitas/index', $data, FALSE);
        }
         else 
        {
            $this->session->sess_destroy();
            
            $data= $this->Travelku->Get('travel');
            $data= array('data' => $data);
            $this->load->view('home/index', $data, FALSE);
            
        }
        
    }

    public function pesanan()
    {
        $listkursi= $this->session->userdata('kursi');
        $data['kursi']= array_values($listkursi);

        $nama= $_POST['nama'];
        $this->session->set_userdata('nama',$nama);
        $data['nama']= $nama;

        $umur = $_POST['umur'];
        $this->session->set_userdata('umur', $umur);
        $data['umur'] = $umur;

        $no_ktp= $_POST['no_ktp'];
        $this->session->set_userdata('no_ktp', $no_ktp);
        $data['no_ktp']= $no_ktp;


        $data=array('data' => $data);
        $this->load->view('pesanan/index', $data, FALSE);
        
    }

    public function hapusKursi($no)
    {
        $listkursi= $this->session->userdata('kursi');
        $listnama= $this->session->userdata('nama');
        $listumur= $this->session->userdata('umur');
        $listktp= $this->session->userdata('no_ktp');


        ///unset
        unset($listkursi[$no]);
        unset($listnama[$no]);
        unset($listumur[$no]);
        unset($listktp[$no]);


        ///masukan data variabel ke arrray
        $data['kursi']= array_values($listkursi);
        $data['nama']= array_values($listnama);
        $data['umur']= array_values($listumur);
        $data['no_ktp']= array_values($listktp);

        ///mengurutkan index
        $kursi = $data['kursi'];
        $nama = $data['nama'];
        $umur = $data['umur'];
        $no_ktp = $data['no_ktp'];


	//set session dengan data kursi 
    $this->session->set_userdata('kursi', $kursi);
    $this->session->set_userdata('nama', $nama);
    $this->session->set_userdata('umur', $umur);
    $this->session->set_userdata('no_ktp', $no_ktp);


    $data=array('data' => $data);
    $this->load->view('pesanan/index', $data, FALSE);
    

    }

    public function edit()
    {
        //masukkan ke var listkursi dengan session kursi, lalu jadikan array ke variabel kursi
		$listkursi = $this->session->userdata('kursi');
		$kursi = array_values($listkursi);

		//masukkan ke masing masing var dengan sessionnya
		$id_travel= $this->session->userdata('id_travel');
		$id_jadwal= $this->session->userdata('id_jadwal');
        $tanggal_pesan = $this->session->userdata('tanggal_pesan');

		//ambil semua data film berdasarkan id film dari session id_film
		$data['travel'] = $this->Travelku->Get_where('travel', array('id_travel' => $id_travel)); 

		//ambil semua data kursi
		$data['kursi'] = $this->Travelku->Get('kursi');
		
		//ambil data kursi untuk kursi yang sudah dipilih sebelumnya
		$data['kursi_checked'] = $kursi;

		//ambil kursi terbooking dan masukkan ke var array
		$query_kursi_booked = $this->db->query('SELECT nokur FROM pesanan where 
		id_travel = "'.$id_travel.'" and id_jadwal="'.$id_jadwal.'" and tanggal_pesan="'.$tanggal_pesan.'"');
		
		$data['kursi_booked'] = $query_kursi_booked->result_array();

		//simpan semua data kedalam variabel array 'data' lalu masukkan ke view 'edit'
		$data = array('data' => $data);
		$this->load->view('edit/index', $data);
    }

    public function bayar()
    {
           //mauskan ke var listkursi dengan session kursi, lalu jadikan array ke variable kursi
       		//masukkan ke var listkursi dengan session kursi, lalu jadikan array ke variabel kursi
		$listkursi = $this->session->userdata('kursi');
		$data['kursi'] = array_values($listkursi);

		$listnama = $this->session->userdata('nama');
		$data['nama'] = array_values($listnama);

		$listumur = $this->session->userdata('umur');
		$data['umur'] = array_values($listumur);

		$listktp = $this->session->userdata('no_ktp');
		$data['no_ktp'] = array_values($listktp);

		//hitung isi data kursi
		$jum_kursi = count($data['kursi']);
        
        $i=0;

		//insert data kursi ke database berdasalkan jumlahnya
		foreach($data['kursi'] as $k){
			$data_insert = array(
				'id_travel' => $this->session->userdata('id_travel'),
				'tanggal_pesan' =>  $this->session->userdata('tanggal_pesan'),
				'id_jadwal' => $this->session->userdata('id_jadwal'),
				'nokur' => $k,
				'nama' => $data['nama'][$i],
				'umur' => $data['umur'][$i],
				'no_ktp' => $data['no_ktp'][$i]
			);
			// print_r($data_insert);	
            $i++;
            
			$this->Travelku->Insert('pesanan', $data_insert);		
		}
		//simpan semua data kedalam variabel array 'data' lalu masukkan ke view 'edit'
		$data = array('data' => $data);
		$this->load->view('tiket/index', $data);
    }




}

/* End of file Controllername.php */


?>