<?php $this->load->view('header.php') ?>
    <div class="slideshow-container">
        <div class="mySlides fade">
            <img src="<?= base_url(); ?>assets/images/tayo1.jpg" style="width:100%" alt="">
        </div>
        <div class="mySlides fade">
            <img src="<?= base_url(); ?>assets/images/tayo2.jpg" style="width:100%" alt="">
        </div>
        <div class="mySlides fade">
            <img src="<?= base_url(); ?>assets/images/tayo3.jpg" style="width:100%" alt="">
        </div>
    </div>
    <br>
    <div style="text-align:center" >
        <span class="dot" onclick="currentSlide(1)" ></span>
        <span class="dot" onclick="currentSlide(2)" ></span>
        <span class="dot" onclick="currentSlide(3)" ></span>
    </div>
    <!-- <marquee>Harga Rp 60.000,00/ tiket setiap hari</marquee>
    <br><h2 align="center">Film Terbaru</h2><br> -->
    <div class="content">
        <form method="post" action="<?= base_url(); ?>index.php/Travel/pesan">
            <table>
                <tr>
                    <?php foreach($data as $film){ ?>
                    <td>
                        <center>
                            <img height="450px" src="<?= base_url(); ?>assets/images/<?= $film['foto']; ?>">
                            <h5><?= $film['nama_travel']; ?></h5>
                        </center>
                        <p><?= $film['sinopsis']; ?></p>
                        <button class="btn" name="id_travel" value="<?= $film['id_travel']; ?>" type="submit">Pesan</button>
                        <small><?= $film['keterangan']; ?></small>
                        <br><br>
                    </td>
                    <?php } ?>
                    
                </tr>
            </table>
        </form>
    </div>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/tiku_slider.js" ></script>
</body>
</html>