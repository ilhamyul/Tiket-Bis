<?php $this->load->view('header') ?>
<div class="content" id="printableArea">
    <h2 align="center">Tiket</h2>
    <br>
    <?php $i=0; foreach($data['kursi'] as $kursi) { ?>
        <hr width="50%" align="left" >
        <h6>Tiket Bioskop Kampus UDINUS (TIKU)</h6><hr>
        <p><b><?= $this->session->userdata("nama_travel"); ?></b>
        <br>
        <?php $tn=$this->session->userdata("tanggal_pesan");
        echo date('l', strtotime($tn)).", ".$tn."/ ".$this->session->userdata("jadwal"); ?>
        <br>
        <!--TAMBAHKAN INI  -->
        Nama &nbsp;: <?php echo $data['nama'][$i]; ?><br>
        Umur &nbsp;: <?php echo $data['umur'][$i]; ?><br>
        KTP &ensp;: <?php echo $data['no_ktp'][$i]; ?><br>
        <!--TAMBAHKAN INI  -->
        <br>
        Kursi : <?= $kursi ?> </p>

        <small><br><hr width="50%" align="left" style="border-top: 1px dashed;">disobek untuk petugas<br>Tiket Bioskop Kampus UDINUS (TIKU)
        <b><?= $this->session->userdata("nama_travel"); ?> - <?php $tn = $this->session->userdata("tangal_pesan");
        echo date('l', strtotime($tn)).", ".$tn."/ ".$this->session->userdata("jadwal"); ?> - <?= $kursi; ?></b></small>
        <hr width="50%" align="left" >
    <?php $i++;} ?>

    <button class="btn" onclick="print()">Print</button>
</div>
<script>
    function print() {
        $('#printableArea').html2canvas({
            onrendered: function( canvas ){
            var img = canvas.toDataURL()
            window.open(img);
            
        })
    }

</script>
</body>
</html>

