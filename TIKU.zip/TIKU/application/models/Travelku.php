<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class Travelku extends CI_Model {

    public function Get($table)
    {
            $res=$this->db->get($table)->result_array();
            return $res;
    }

    public function Get_where($table,$data)
    {
        $res=$this->db->get_where($table,$data)->result_array();
        return $res;
        
    }

    public function Insert($table,$data)
    {
        $res=$this->db->insert($table, $data);
        return $res;
        
    }

    public function Update($table, $data, $where)
    {
        $res=$this->db->update($table, $data, $where);
        return $res;
        
    }

    public function Delete($table,$data)
    {
        $res=$this->db->delete($table, $data);
        return $res;
        
    }

}

/* End of file .php */

?>